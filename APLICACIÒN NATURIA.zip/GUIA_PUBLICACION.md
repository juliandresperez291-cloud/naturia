# 📱 NaturIA — Guía de Publicación

## Paso 1: Subir a GitHub Pages (GRATIS)

1. Ve a https://github.com y crea una cuenta (si no tienes)
2. Haz clic en "New repository"
3. Nombre: `naturia` (en minúsculas)
4. Marca como "Public" ✅
5. Haz clic en "Create repository"
6. Arrastra y suelta los 3 archivos:
   - index.html
   - manifest.json
   - service-worker.js
7. Haz clic en "Commit changes"
8. Ve a Settings → Pages
9. En "Branch" selecciona "main" y haz clic en "Save"
10. ¡Espera 2 minutos! Tu URL será:
    https://TU-USUARIO.github.io/naturia/

---

## Paso 2: Instalar en el celular (Android)

1. Abre Chrome en el celular
2. Ve a tu URL de GitHub Pages
3. Toca el menú ⋮ (tres puntos)
4. Selecciona "Agregar a pantalla de inicio"
5. ¡Listo! Aparece como app nativa 📱

## Paso 2: Instalar en el celular (iPhone)

1. Abre Safari (no Chrome)
2. Ve a tu URL de GitHub Pages
3. Toca el botón de compartir □↑
4. Toca "Agregar a pantalla de inicio"
5. ¡Listo! 📱

---

## Paso 3: Crear código QR para la feria

1. Ve a https://qr-code-generator.com
2. Pega tu URL de GitHub Pages
3. Descarga el QR en alta resolución
4. Imprímelo grande para el stand

---

## ¿Dónde poner la API Key?

La app usa la API de Claude (Anthropic).
En el archivo index.html, el chat ya está configurado.
La API key se maneja automáticamente en claude.ai.

Para versión con tu propia API key:
Busca en index.html la función askClaude() y
reemplaza la URL por tu endpoint con tu key.

---

Creado con ❤️ para IE Luis Andrade Valderrama
